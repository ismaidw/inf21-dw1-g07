export * from './filmes.repository';
export * from './localizacao-filmagem.repository';
export * from './premios.repository';
