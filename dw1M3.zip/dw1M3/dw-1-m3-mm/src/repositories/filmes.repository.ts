import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyThroughRepositoryFactory} from '@loopback/repository';
import {DbmmDataSource} from '../datasources';
import {Filmes, FilmesRelations, LocalizacaoFilmagem, Premios} from '../models';
import {PremiosRepository} from './premios.repository';
import {LocalizacaoFilmagemRepository} from './localizacao-filmagem.repository';

export class FilmesRepository extends DefaultCrudRepository<
  Filmes,
  typeof Filmes.prototype.id,
  FilmesRelations
> {

  public readonly localizacaoFilmagems: HasManyThroughRepositoryFactory<LocalizacaoFilmagem, typeof LocalizacaoFilmagem.prototype.id,
          Premios,
          typeof Filmes.prototype.id
        >;

  constructor(
    @inject('datasources.dbmm') dataSource: DbmmDataSource, @repository.getter('PremiosRepository') protected premiosRepositoryGetter: Getter<PremiosRepository>, @repository.getter('LocalizacaoFilmagemRepository') protected localizacaoFilmagemRepositoryGetter: Getter<LocalizacaoFilmagemRepository>,
  ) {
    super(Filmes, dataSource);
    this.localizacaoFilmagems = this.createHasManyThroughRepositoryFactoryFor('localizacaoFilmagems', localizacaoFilmagemRepositoryGetter, premiosRepositoryGetter,);
    this.registerInclusionResolver('localizacaoFilmagems', this.localizacaoFilmagems.inclusionResolver);
  }
}
