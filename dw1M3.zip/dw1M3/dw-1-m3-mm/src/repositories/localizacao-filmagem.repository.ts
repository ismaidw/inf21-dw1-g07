import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyThroughRepositoryFactory} from '@loopback/repository';
import {DbmmDataSource} from '../datasources';
import {LocalizacaoFilmagem, LocalizacaoFilmagemRelations, Filmes, Premios} from '../models';
import {PremiosRepository} from './premios.repository';
import {FilmesRepository} from './filmes.repository';

export class LocalizacaoFilmagemRepository extends DefaultCrudRepository<
  LocalizacaoFilmagem,
  typeof LocalizacaoFilmagem.prototype.id,
  LocalizacaoFilmagemRelations
> {

  public readonly filmes: HasManyThroughRepositoryFactory<Filmes, typeof Filmes.prototype.id,
          Premios,
          typeof LocalizacaoFilmagem.prototype.id
        >;

  constructor(
    @inject('datasources.dbmm') dataSource: DbmmDataSource, @repository.getter('PremiosRepository') protected premiosRepositoryGetter: Getter<PremiosRepository>, @repository.getter('FilmesRepository') protected filmesRepositoryGetter: Getter<FilmesRepository>,
  ) {
    super(LocalizacaoFilmagem, dataSource);
    this.filmes = this.createHasManyThroughRepositoryFactoryFor('filmes', filmesRepositoryGetter, premiosRepositoryGetter,);
    this.registerInclusionResolver('filmes', this.filmes.inclusionResolver);
  }
}
