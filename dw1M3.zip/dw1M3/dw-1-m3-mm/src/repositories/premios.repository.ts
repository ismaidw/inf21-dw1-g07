import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbmmDataSource} from '../datasources';
import {Premios, PremiosRelations} from '../models';

export class PremiosRepository extends DefaultCrudRepository<
  Premios,
  typeof Premios.prototype.id,
  PremiosRelations
> {
  constructor(
    @inject('datasources.dbmm') dataSource: DbmmDataSource,
  ) {
    super(Premios, dataSource);
  }
}
