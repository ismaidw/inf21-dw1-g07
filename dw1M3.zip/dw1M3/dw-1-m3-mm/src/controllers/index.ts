export * from './ping.controller';
export * from './filmes-localizacao-filmagem.controller';
export * from './filmes.controller';
export * from './localizacao-filmagem-filmes.controller';
export * from './localizacao-filmagem.controller';
export * from './premios.controller';
