import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Premios} from '../models';
import {PremiosRepository} from '../repositories';

export class PremiosController {
  constructor(
    @repository(PremiosRepository)
    public premiosRepository : PremiosRepository,
  ) {}

  @post('/premios')
  @response(200, {
    description: 'Premios model instance',
    content: {'application/json': {schema: getModelSchemaRef(Premios)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Premios, {
            title: 'NewPremios',
            exclude: ['id'],
          }),
        },
      },
    })
    premios: Omit<Premios, 'id'>,
  ): Promise<Premios> {
    return this.premiosRepository.create(premios);
  }

  @get('/premios/count')
  @response(200, {
    description: 'Premios model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Premios) where?: Where<Premios>,
  ): Promise<Count> {
    return this.premiosRepository.count(where);
  }

  @get('/premios')
  @response(200, {
    description: 'Array of Premios model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Premios, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Premios) filter?: Filter<Premios>,
  ): Promise<Premios[]> {
    return this.premiosRepository.find(filter);
  }

  @patch('/premios')
  @response(200, {
    description: 'Premios PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Premios, {partial: true}),
        },
      },
    })
    premios: Premios,
    @param.where(Premios) where?: Where<Premios>,
  ): Promise<Count> {
    return this.premiosRepository.updateAll(premios, where);
  }

  @get('/premios/{id}')
  @response(200, {
    description: 'Premios model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Premios, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Premios, {exclude: 'where'}) filter?: FilterExcludingWhere<Premios>
  ): Promise<Premios> {
    return this.premiosRepository.findById(id, filter);
  }

  @patch('/premios/{id}')
  @response(204, {
    description: 'Premios PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Premios, {partial: true}),
        },
      },
    })
    premios: Premios,
  ): Promise<void> {
    await this.premiosRepository.updateById(id, premios);
  }

  @put('/premios/{id}')
  @response(204, {
    description: 'Premios PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() premios: Premios,
  ): Promise<void> {
    await this.premiosRepository.replaceById(id, premios);
  }

  @del('/premios/{id}')
  @response(204, {
    description: 'Premios DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.premiosRepository.deleteById(id);
  }
}
