import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
  import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
Filmes,
Premios,
LocalizacaoFilmagem,
} from '../models';
import {FilmesRepository} from '../repositories';

export class FilmesLocalizacaoFilmagemController {
  constructor(
    @repository(FilmesRepository) protected filmesRepository: FilmesRepository,
  ) { }

  @get('/filmes/{id}/localizacao-filmagems', {
    responses: {
      '200': {
        description: 'Array of Filmes has many LocalizacaoFilmagem through Premios',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(LocalizacaoFilmagem)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<LocalizacaoFilmagem>,
  ): Promise<LocalizacaoFilmagem[]> {
    return this.filmesRepository.localizacaoFilmagems(id).find(filter);
  }

  @post('/filmes/{id}/localizacao-filmagems', {
    responses: {
      '200': {
        description: 'create a LocalizacaoFilmagem model instance',
        content: {'application/json': {schema: getModelSchemaRef(LocalizacaoFilmagem)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Filmes.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LocalizacaoFilmagem, {
            title: 'NewLocalizacaoFilmagemInFilmes',
            exclude: ['id'],
          }),
        },
      },
    }) localizacaoFilmagem: Omit<LocalizacaoFilmagem, 'id'>,
  ): Promise<LocalizacaoFilmagem> {
    return this.filmesRepository.localizacaoFilmagems(id).create(localizacaoFilmagem);
  }

  @patch('/filmes/{id}/localizacao-filmagems', {
    responses: {
      '200': {
        description: 'Filmes.LocalizacaoFilmagem PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LocalizacaoFilmagem, {partial: true}),
        },
      },
    })
    localizacaoFilmagem: Partial<LocalizacaoFilmagem>,
    @param.query.object('where', getWhereSchemaFor(LocalizacaoFilmagem)) where?: Where<LocalizacaoFilmagem>,
  ): Promise<Count> {
    return this.filmesRepository.localizacaoFilmagems(id).patch(localizacaoFilmagem, where);
  }

  @del('/filmes/{id}/localizacao-filmagems', {
    responses: {
      '200': {
        description: 'Filmes.LocalizacaoFilmagem DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(LocalizacaoFilmagem)) where?: Where<LocalizacaoFilmagem>,
  ): Promise<Count> {
    return this.filmesRepository.localizacaoFilmagems(id).delete(where);
  }
}
