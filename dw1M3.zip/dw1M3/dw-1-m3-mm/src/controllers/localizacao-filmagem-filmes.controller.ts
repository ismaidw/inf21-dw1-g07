import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
  import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
LocalizacaoFilmagem,
Premios,
Filmes,
} from '../models';
import {LocalizacaoFilmagemRepository} from '../repositories';

export class LocalizacaoFilmagemFilmesController {
  constructor(
    @repository(LocalizacaoFilmagemRepository) protected localizacaoFilmagemRepository: LocalizacaoFilmagemRepository,
  ) { }

  @get('/localizacao-filmagems/{id}/filmes', {
    responses: {
      '200': {
        description: 'Array of LocalizacaoFilmagem has many Filmes through Premios',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Filmes)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Filmes>,
  ): Promise<Filmes[]> {
    return this.localizacaoFilmagemRepository.filmes(id).find(filter);
  }

  @post('/localizacao-filmagems/{id}/filmes', {
    responses: {
      '200': {
        description: 'create a Filmes model instance',
        content: {'application/json': {schema: getModelSchemaRef(Filmes)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof LocalizacaoFilmagem.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Filmes, {
            title: 'NewFilmesInLocalizacaoFilmagem',
            exclude: ['id'],
          }),
        },
      },
    }) filmes: Omit<Filmes, 'id'>,
  ): Promise<Filmes> {
    return this.localizacaoFilmagemRepository.filmes(id).create(filmes);
  }

  @patch('/localizacao-filmagems/{id}/filmes', {
    responses: {
      '200': {
        description: 'LocalizacaoFilmagem.Filmes PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Filmes, {partial: true}),
        },
      },
    })
    filmes: Partial<Filmes>,
    @param.query.object('where', getWhereSchemaFor(Filmes)) where?: Where<Filmes>,
  ): Promise<Count> {
    return this.localizacaoFilmagemRepository.filmes(id).patch(filmes, where);
  }

  @del('/localizacao-filmagems/{id}/filmes', {
    responses: {
      '200': {
        description: 'LocalizacaoFilmagem.Filmes DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Filmes)) where?: Where<Filmes>,
  ): Promise<Count> {
    return this.localizacaoFilmagemRepository.filmes(id).delete(where);
  }
}
