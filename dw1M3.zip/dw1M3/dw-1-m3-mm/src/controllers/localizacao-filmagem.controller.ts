import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {LocalizacaoFilmagem} from '../models';
import {LocalizacaoFilmagemRepository} from '../repositories';

export class LocalizacaoFilmagemController {
  constructor(
    @repository(LocalizacaoFilmagemRepository)
    public localizacaoFilmagemRepository : LocalizacaoFilmagemRepository,
  ) {}

  @post('/localizacao-filmagems')
  @response(200, {
    description: 'LocalizacaoFilmagem model instance',
    content: {'application/json': {schema: getModelSchemaRef(LocalizacaoFilmagem)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LocalizacaoFilmagem, {
            title: 'NewLocalizacaoFilmagem',
            exclude: ['id'],
          }),
        },
      },
    })
    localizacaoFilmagem: Omit<LocalizacaoFilmagem, 'id'>,
  ): Promise<LocalizacaoFilmagem> {
    return this.localizacaoFilmagemRepository.create(localizacaoFilmagem);
  }

  @get('/localizacao-filmagems/count')
  @response(200, {
    description: 'LocalizacaoFilmagem model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(LocalizacaoFilmagem) where?: Where<LocalizacaoFilmagem>,
  ): Promise<Count> {
    return this.localizacaoFilmagemRepository.count(where);
  }

  @get('/localizacao-filmagems')
  @response(200, {
    description: 'Array of LocalizacaoFilmagem model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(LocalizacaoFilmagem, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(LocalizacaoFilmagem) filter?: Filter<LocalizacaoFilmagem>,
  ): Promise<LocalizacaoFilmagem[]> {
    return this.localizacaoFilmagemRepository.find(filter);
  }

  @patch('/localizacao-filmagems')
  @response(200, {
    description: 'LocalizacaoFilmagem PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LocalizacaoFilmagem, {partial: true}),
        },
      },
    })
    localizacaoFilmagem: LocalizacaoFilmagem,
    @param.where(LocalizacaoFilmagem) where?: Where<LocalizacaoFilmagem>,
  ): Promise<Count> {
    return this.localizacaoFilmagemRepository.updateAll(localizacaoFilmagem, where);
  }

  @get('/localizacao-filmagems/{id}')
  @response(200, {
    description: 'LocalizacaoFilmagem model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(LocalizacaoFilmagem, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(LocalizacaoFilmagem, {exclude: 'where'}) filter?: FilterExcludingWhere<LocalizacaoFilmagem>
  ): Promise<LocalizacaoFilmagem> {
    return this.localizacaoFilmagemRepository.findById(id, filter);
  }

  @patch('/localizacao-filmagems/{id}')
  @response(204, {
    description: 'LocalizacaoFilmagem PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LocalizacaoFilmagem, {partial: true}),
        },
      },
    })
    localizacaoFilmagem: LocalizacaoFilmagem,
  ): Promise<void> {
    await this.localizacaoFilmagemRepository.updateById(id, localizacaoFilmagem);
  }

  @put('/localizacao-filmagems/{id}')
  @response(204, {
    description: 'LocalizacaoFilmagem PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() localizacaoFilmagem: LocalizacaoFilmagem,
  ): Promise<void> {
    await this.localizacaoFilmagemRepository.replaceById(id, localizacaoFilmagem);
  }

  @del('/localizacao-filmagems/{id}')
  @response(204, {
    description: 'LocalizacaoFilmagem DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.localizacaoFilmagemRepository.deleteById(id);
  }
}
