import {Entity, model, property, hasMany} from '@loopback/repository';
import {LocalizacaoFilmagem} from './localizacao-filmagem.model';
import {Premios} from './premios.model';

@model()
export class Filmes extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  titulo: string;

  @property({
    type: 'string',
  })
  anoLancamento?: string;

  @property({
    type: 'number',
    required: true,
  })
  ano_Lancamento: number;

  @property({
    type: 'string',
    required: true,
  })
  linguagem: string;

  @property({
    type: 'number',
    required: true,
  })
  duracao: number;

  @property({
    type: 'number',
    required: true,
  })
  avaliacao: number;

  @hasMany(() => LocalizacaoFilmagem, {through: {model: () => Premios}})
  localizacaoFilmagems: LocalizacaoFilmagem[];

  constructor(data?: Partial<Filmes>) {
    super(data);
  }
}

export interface FilmesRelations {
  // describe navigational properties here
}

export type FilmesWithRelations = Filmes & FilmesRelations;
