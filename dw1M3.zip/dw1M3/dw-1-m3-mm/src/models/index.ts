export * from './premios.model';
export * from './filmes.model';
export * from './localizacao-filmagem.model';
