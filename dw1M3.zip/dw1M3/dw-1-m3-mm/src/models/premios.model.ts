import {Entity, model, property} from '@loopback/repository';

@model()
export class Premios extends Entity {
  @property({
    type: 'string',
    required: true,
  })
  premio1: string;

  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  premio2: string;

  @property({
    type: 'string',
    required: true,
  })
  premio3: string;

  @property({
    type: 'number',
  })
  filmesId?: number;

  @property({
    type: 'number',
  })
  localizacaoFilmagemId?: number;

  constructor(data?: Partial<Premios>) {
    super(data);
  }
}

export interface PremiosRelations {
  // describe navigational properties here
}

export type PremiosWithRelations = Premios & PremiosRelations;
