import {Entity, model, property, hasMany} from '@loopback/repository';
import {Filmes} from './filmes.model';
import {Premios} from './premios.model';

@model()
export class LocalizacaoFilmagem extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  localizacao1: string;

  @property({
    type: 'string',
    required: true,
  })
  localizacao2: string;

  @property({
    type: 'string',
    required: true,
  })
  localizacao3: string;

  @property({
    type: 'string',
    required: true,
  })
  localizacao4: string;

  @hasMany(() => Filmes, {through: {model: () => Premios}})
  filmes: Filmes[];

  constructor(data?: Partial<LocalizacaoFilmagem>) {
    super(data);
  }
}

export interface LocalizacaoFilmagemRelations {
  // describe navigational properties here
}

export type LocalizacaoFilmagemWithRelations = LocalizacaoFilmagem & LocalizacaoFilmagemRelations;
