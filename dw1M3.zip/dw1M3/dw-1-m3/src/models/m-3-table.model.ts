import {Entity, model, property, belongsTo} from '@loopback/repository';
import {M3} from './m3.model';

@model()
export class M3Table extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  localizacao1Filme: string;

  @property({
    type: 'string',
    required: true,
  })
  localizacao2Filme: string;

  @property({
    type: 'string',
    required: true,
  })
  localizacao3Filme: string;

  @belongsTo(() => M3)
  m3Id: number;

  constructor(data?: Partial<M3Table>) {
    super(data);
  }
}

export interface M3TableRelations {
  // describe navigational properties here
}

export type M3TableWithRelations = M3Table & M3TableRelations;
