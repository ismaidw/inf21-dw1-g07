import {Entity, model, property, hasMany} from '@loopback/repository';
import {M3Table} from './m-3-table.model';

@model()
export class M3 extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'number',
    required: true,
  })
  ano

  @hasMany(() => M3Table)
  m3Tables: M3Table[];
-lancamento: number;

  @property({
    type: 'string',
    required: true,
  })
  linguagem: string;

  @property({
    type: 'number',
    required: true,
  })
  duracao: number;

  @property({
    type: 'number',
    required: true,
  })
  avaliacao: number;


  constructor(data?: Partial<M3>) {
    super(data);
  }
}

export interface M3Relations {
  // describe navigational properties here
}

export type M3WithRelations = M3 & M3Relations;
