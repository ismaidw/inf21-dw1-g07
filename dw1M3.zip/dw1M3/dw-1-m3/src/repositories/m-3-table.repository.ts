import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, BelongsToAccessor} from '@loopback/repository';
import {DbtDataSource} from '../datasources';
import {M3Table, M3TableRelations, M3} from '../models';
import {M3Repository} from './m3.repository';

export class M3TableRepository extends DefaultCrudRepository<
  M3Table,
  typeof M3Table.prototype.id,
  M3TableRelations
> {

  public readonly m3: BelongsToAccessor<M3, typeof M3Table.prototype.id>;

  constructor(
    @inject('datasources.dbt') dataSource: DbtDataSource, @repository.getter('M3Repository') protected m3RepositoryGetter: Getter<M3Repository>,
  ) {
    super(M3Table, dataSource);
    this.m3 = this.createBelongsToAccessorFor('m3', m3RepositoryGetter,);
    this.registerInclusionResolver('m3', this.m3.inclusionResolver);
  }
}
