import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {M3, M3Relations, M3Table} from '../models';
import {M3TableRepository} from './m-3-table.repository';

export class M3Repository extends DefaultCrudRepository<
  M3,
  typeof M3.prototype.id,
  M3Relations
> {

  public readonly m3Tables: HasManyRepositoryFactory<M3Table, typeof M3.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('M3TableRepository') protected m3TableRepositoryGetter: Getter<M3TableRepository>,
  ) {
    super(M3, dataSource);
    this.m3Tables = this.createHasManyRepositoryFactoryFor('m3Tables', m3TableRepositoryGetter,);
    this.registerInclusionResolver('m3Tables', this.m3Tables.inclusionResolver);
  }
}
