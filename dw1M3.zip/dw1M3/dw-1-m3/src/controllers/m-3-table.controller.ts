import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {M3Table} from '../models';
import {M3TableRepository} from '../repositories';

export class M3TableController {
  constructor(
    @repository(M3TableRepository)
    public m3TableRepository : M3TableRepository,
  ) {}

  @post('/m3tables')
  @response(200, {
    description: 'M3Table model instance',
    content: {'application/json': {schema: getModelSchemaRef(M3Table)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3Table, {
            title: 'NewM3Table',
            exclude: ['id'],
          }),
        },
      },
    })
    m3Table: Omit<M3Table, 'id'>,
  ): Promise<M3Table> {
    return this.m3TableRepository.create(m3Table);
  }

  @get('/m3tables/count')
  @response(200, {
    description: 'M3Table model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(M3Table) where?: Where<M3Table>,
  ): Promise<Count> {
    return this.m3TableRepository.count(where);
  }

  @get('/m3tables')
  @response(200, {
    description: 'Array of M3Table model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(M3Table, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(M3Table) filter?: Filter<M3Table>,
  ): Promise<M3Table[]> {
    return this.m3TableRepository.find(filter);
  }

  @patch('/m3tables')
  @response(200, {
    description: 'M3Table PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3Table, {partial: true}),
        },
      },
    })
    m3Table: M3Table,
    @param.where(M3Table) where?: Where<M3Table>,
  ): Promise<Count> {
    return this.m3TableRepository.updateAll(m3Table, where);
  }

  @get('/m3tables/{id}')
  @response(200, {
    description: 'M3Table model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(M3Table, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(M3Table, {exclude: 'where'}) filter?: FilterExcludingWhere<M3Table>
  ): Promise<M3Table> {
    return this.m3TableRepository.findById(id, filter);
  }

  @patch('/m3tables/{id}')
  @response(204, {
    description: 'M3Table PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3Table, {partial: true}),
        },
      },
    })
    m3Table: M3Table,
  ): Promise<void> {
    await this.m3TableRepository.updateById(id, m3Table);
  }

  @put('/m3tables/{id}')
  @response(204, {
    description: 'M3Table PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() m3Table: M3Table,
  ): Promise<void> {
    await this.m3TableRepository.replaceById(id, m3Table);
  }

  @del('/m3tables/{id}')
  @response(204, {
    description: 'M3Table DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.m3TableRepository.deleteById(id);
  }
}
