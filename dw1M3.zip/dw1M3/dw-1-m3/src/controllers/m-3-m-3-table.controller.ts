import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  M3,
  M3Table,
} from '../models';
import {M3Repository} from '../repositories';

export class M3M3TableController {
  constructor(
    @repository(M3Repository) protected m3Repository: M3Repository,
  ) { }

  @get('/m3s/{id}/m-3-tables', {
    responses: {
      '200': {
        description: 'Array of M3 has many M3Table',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(M3Table)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<M3Table>,
  ): Promise<M3Table[]> {
    return this.m3Repository.m3Tables(id).find(filter);
  }

  @post('/m3s/{id}/m-3-tables', {
    responses: {
      '200': {
        description: 'M3 model instance',
        content: {'application/json': {schema: getModelSchemaRef(M3Table)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof M3.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3Table, {
            title: 'NewM3TableInM3',
            exclude: ['id'],
            optional: ['m3Id']
          }),
        },
      },
    }) m3Table: Omit<M3Table, 'id'>,
  ): Promise<M3Table> {
    return this.m3Repository.m3Tables(id).create(m3Table);
  }

  @patch('/m3s/{id}/m-3-tables', {
    responses: {
      '200': {
        description: 'M3.M3Table PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3Table, {partial: true}),
        },
      },
    })
    m3Table: Partial<M3Table>,
    @param.query.object('where', getWhereSchemaFor(M3Table)) where?: Where<M3Table>,
  ): Promise<Count> {
    return this.m3Repository.m3Tables(id).patch(m3Table, where);
  }

  @del('/m3s/{id}/m-3-tables', {
    responses: {
      '200': {
        description: 'M3.M3Table DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(M3Table)) where?: Where<M3Table>,
  ): Promise<Count> {
    return this.m3Repository.m3Tables(id).delete(where);
  }
}
