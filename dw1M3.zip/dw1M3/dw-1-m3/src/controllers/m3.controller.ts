import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {M3} from '../models';
import {M3Repository} from '../repositories';

export class M3Controller {
  constructor(
    @repository(M3Repository)
    public m3Repository : M3Repository,
  ) {}

  @post('/m3s')
  @response(200, {
    description: 'M3 model instance',
    content: {'application/json': {schema: getModelSchemaRef(M3)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3, {
            title: 'NewM3',
            exclude: ['id'],
          }),
        },
      },
    })
    m3: Omit<M3, 'id'>,
  ): Promise<M3> {
    return this.m3Repository.create(m3);
  }

  @get('/m3s/count')
  @response(200, {
    description: 'M3 model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(M3) where?: Where<M3>,
  ): Promise<Count> {
    return this.m3Repository.count(where);
  }

  @get('/m3s')
  @response(200, {
    description: 'Array of M3 model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(M3, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(M3) filter?: Filter<M3>,
  ): Promise<M3[]> {
    return this.m3Repository.find(filter);
  }

  @patch('/m3s')
  @response(200, {
    description: 'M3 PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3, {partial: true}),
        },
      },
    })
    m3: M3,
    @param.where(M3) where?: Where<M3>,
  ): Promise<Count> {
    return this.m3Repository.updateAll(m3, where);
  }

  @get('/m3s/{id}')
  @response(200, {
    description: 'M3 model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(M3, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(M3, {exclude: 'where'}) filter?: FilterExcludingWhere<M3>
  ): Promise<M3> {
    return this.m3Repository.findById(id, filter);
  }

  @patch('/m3s/{id}')
  @response(204, {
    description: 'M3 PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(M3, {partial: true}),
        },
      },
    })
    m3: M3,
  ): Promise<void> {
    await this.m3Repository.updateById(id, m3);
  }

  @put('/m3s/{id}')
  @response(204, {
    description: 'M3 PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() m3: M3,
  ): Promise<void> {
    await this.m3Repository.replaceById(id, m3);
  }

  @del('/m3s/{id}')
  @response(204, {
    description: 'M3 DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.m3Repository.deleteById(id);
  }
}
