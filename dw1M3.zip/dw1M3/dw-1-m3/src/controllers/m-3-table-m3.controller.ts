import {
  repository,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
} from '@loopback/rest';
import {
  M3Table,
  M3,
} from '../models';
import {M3TableRepository} from '../repositories';

export class M3TableM3Controller {
  constructor(
    @repository(M3TableRepository)
    public m3TableRepository: M3TableRepository,
  ) { }

  @get('/m-3-tables/{id}/m3', {
    responses: {
      '200': {
        description: 'M3 belonging to M3Table',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(M3)},
          },
        },
      },
    },
  })
  async getM3(
    @param.path.number('id') id: typeof M3Table.prototype.id,
  ): Promise<M3> {
    return this.m3TableRepository.m3(id);
  }
}
